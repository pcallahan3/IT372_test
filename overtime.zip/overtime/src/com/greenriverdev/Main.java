package com.greenriverdev;

import java.util.Scanner;
import java.io.File;
import java.io.IOException;

public class Main {

    public static final int WORK_WEEK = 40;
    public static final int REGULAR_PAY = 10;
    public static final int OVERTIME = 12;
    public static final int SUNDAY_PAY = 15;
    public static final int SATURDAY_PAY = 20;

    public static void main(String[] args) throws IOException {
        Scanner stdin = new Scanner(System.in);
        System.out.print("Filename: ");
        String name = stdin.nextLine();
        File file = new File(name);
        Scanner fileIn = new Scanner(file);
        int numRows = fileIn.nextInt();
        fileIn.nextLine();

        // System.out.println(numRows);

        //Output number of rows
        for (int i = 0; i < numRows; i++) {
            String line = fileIn.nextLine();
            System.out.println(line);
            Scanner lineIn = new Scanner(line);
            int[] timesheet = new int[7];   // 7 days in the week
            double totalHours = 0;
            double totalPay = 0;
            double extraHours = 0;
            double overEightPay = 0;

            //Calculate total hours
            for (int j = 0; j < 7; j++) {
                timesheet[j] = lineIn.nextInt();
                totalHours += timesheet[j];

                //  Calculate total pay
                if (totalHours <= WORK_WEEK) {
                    totalPay = totalHours * REGULAR_PAY;

                    if (timesheet[j] > 8) {
                        extraHours = (timesheet[j] - 8);
                        totalPay = totalPay + (extraHours * 2);
                    }
                }


                if(totalHours >= WORK_WEEK) {
                    totalPay = (WORK_WEEK * REGULAR_PAY) + ((totalHours - WORK_WEEK) * 4); // reg + overtime
                }



            }
            System.out.println(totalPay);
        }
    }


}




